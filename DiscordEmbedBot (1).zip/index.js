const { Client, GatewayIntentBits, EmbedBuilder, REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

// ضع توكن البوت هنا بين علامتي التنصيص
const TOKEN = 'YOUR_BOT_TOKEN_HERE';

const client = new Client({
    intents: [GatewayIntentBits.Guilds]
});

const commands = [
    new SlashCommandBuilder()
        .setName('embed')
        .setDescription('إرسال رسالة إيمباد مخصصة')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
        .addStringOption(option =>
            option.setName('description')
                .setDescription('محتوى الرسالة')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('title')
                .setDescription('عنوان الإيمباد')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('color')
                .setDescription('لون الإيمباد بصيغة Hex مثل #0099ff')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('image')
                .setDescription('رابط صورة كبيرة داخل الإيمباد')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('thumbnail')
                .setDescription('رابط صورة مصغرة')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('footer')
                .setDescription('نص التذييل في الأسفل')
                .setRequired(false))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('الروم المراد الإرسال فيه (اختياري)')
                .setRequired(false))
].map(command => command.toJSON());

client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}`);
    const rest = new REST({ version: '10' }).setToken(TOKEN);
    try {
        await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
        console.log('Slash commands registered!');
    } catch (error) {
        console.error(error);
    }
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === 'embed') {
        const title = interaction.options.getString('title');
        const description = interaction.options.getString('description').replace(/\\n/g, '\n');
        const color = interaction.options.getString('color') || '#2b2d31';
        const image = interaction.options.getString('image');
        const thumbnail = interaction.options.getString('thumbnail');
        const footer = interaction.options.getString('footer');
        const targetChannel = interaction.options.getChannel('channel') || interaction.channel;

        const embed = new EmbedBuilder()
            .setDescription(description);

        try {
            embed.setColor(color);
        } catch {
            embed.setColor('#2b2d31');
        }

        if (title) embed.setTitle(title);
        if (image) embed.setImage(image);
        if (thumbnail) embed.setThumbnail(thumbnail);
        if (footer) embed.setFooter({ text: footer });

        try {
            await targetChannel.send({ embeds: [embed] });
            await interaction.reply({ content: 'تم إرسال الإيمباد بنجاح.', ephemeral: true });
        } catch (err) {
            await interaction.reply({ content: 'حدث خطأ أثناء الإرسال. تأكد من صلاحيات البوت في الروم أو صحة روابط الصور.', ephemeral: true });
        }
    }
});

client.login(TOKEN);
